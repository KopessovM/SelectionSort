import UIKit

// SELECTION SORT

var array = [2, 4, 5, 1, 7, 3, 9, -1, 11]

for i in 0..<array.count {
    var m = i
    for index in i..<array.count {
        // We find index of the smallest element
        if array[m] > array[index] {
            m = index
        }
    }
    // Swap smallest element with another
    if m != i {
        let temp = array[m]
        array[m] = array[i]
        array[i] = temp
    }
}
print(array)

